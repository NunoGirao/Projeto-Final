import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import NavBar from '../components/navbar';

const EventDetails = () => {
  const { id } = useParams();
  const [event, setEvent] = useState(null);

  useEffect(() => {
    const fetchEvent = async () => {
      try {
        const response = await fetch(`http://localhost:5555/api/events/${id}`);
        if (!response.ok) {
          throw new Error('Failed to fetch event details');
        }
        const data = await response.json();
        setEvent(data);
      } catch (error) {
        console.error("Error fetching event details:", error);
      }
    };

    fetchEvent();
  }, [id]);

  if (!event) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <NavBar />
      <div className="container mx-auto p-4">
        <h1 className="text-3xl font-bold mb-4">{event.name}</h1>
        <img src={event.image} alt={event.name} className="w-full h-auto mb-4" />
        <p className="mb-4"><strong>Tipo:</strong> {event.type}</p>
        <p className="mb-4"><strong>Subtipo:</strong> {event.subtype}</p>
        <p className="mb-4"><strong>Data:</strong> {new Date(event.date).toLocaleDateString()}</p>
        <p className="mb-4"><strong>Preço:</strong> R${event.price}</p>
        <p className="mb-4"><strong>Ocupação:</strong> {event.occupation}</p>
        <p className="mb-4"><strong>Capacidade:</strong> {event.capacity}</p>
        <p className="mb-4"><strong>Local:</strong> {event.place.name}</p>
        <p className="mb-4">{event.description}</p>
      </div>
    </div>
  );
};

export default EventDetails;
