import React from 'react';
import { Link } from 'react-router-dom';
import logo from '../assets/logo.png';
import NavBar from "../components/navbar";

const TeatroArte = () => {
    // Assuming topSpacing is defined elsewhere
    const topSpacing = 0; // You can adjust this value as needed

    return (
        <div>
            <NavBar />
        </div>
    );
};

export default TeatroArte;